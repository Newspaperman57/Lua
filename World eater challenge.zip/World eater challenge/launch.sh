#!/bin/sh
java -Xmx3G -Xms2G -jar Tekkit.jar nogui